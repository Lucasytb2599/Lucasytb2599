// Le bot Xonia à était dev par Lucas ytb2599
const Discord = require ("discord.js");
const client = new Discord.Client({
    intents:[3276799]
});
const { token } = require("./config.json")

client.on("ready", () => {
console.log(`Le bot Xonia Est Bien ON `);
});

client.login(token);